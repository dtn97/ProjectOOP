#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "rapidxml/rapidxml.hpp"			// dùng thư viện rapidxml

using namespace std;
using namespace rapidxml;		// dùng thư viện rapidxml

int main(void)
{
	string input_xml;
	string line;
	ifstream in("sample.svg");

	if (!in)
		return 1;				// không mở được file sample.svg

	// đọc toàn bộ nội dung file vào string input_xml
	while(getline(in,line))
		input_xml += line;

	in.close();

	// tạo một mảng (vector) char từ input_xml
	vector<char> xml_copy(input_xml.begin(), input_xml.end());
	xml_copy.push_back('\0');	// thêm kí tự kết thúc chuỗi

	// dùng doc để dọc trên xml_copy
	xml_document<> doc;
	doc.parse<parse_declaration_node | parse_no_data_nodes>(&xml_copy[0]);

	// lấy thẻ svg đầu tiên, gán vào node
	xml_node<> *node = doc.first_node("svg");

	// node->first_node() lấy thẻ (tag) con đầu tiên của svg
	
	node = node->first_node();
	do
	{
		// cứ mỗi một tag (hay node), duyệt qua các thuộc tính
		// node->first_attribute() lấy thuộc tính đầu tiên
		// attr->next_attribute() lấy thuộc tính tiếp theo thuộc tính hiện tại
		for (xml_attribute<> *attr = node->first_attribute();
			 attr; attr = attr->next_attribute())
		{
			// node->name() cho biết tên tag, như svg hay line, circle v.v.
			// mỗi thuộc tính có tên thuộc tính: như stroke, và giá trị
			// như rgb(0,255,0). Tất cả đều là chuỗi (char*)
			cout << "Node " << node->name() << " has attribute " << attr->name() << " ";
			cout << "with value " << attr->value() << "\n";
		}
		
		// sau khi duyệt xong tag hiện tại, đi đến tag tiếp theo ngang cấp
		// bằng node->next_sibling()
		// nếu muốn lấy con thì node->first_node()
		node = node->next_sibling();
	}
	while (node);		// cho đến khi không lấy được tag tiếp theo (giống như linked list)

	// không cần giải phóng gì cả (*node hay *attribute) vì dữ liệu do doc (xml_document<>)
	// quản lý, mà doc sẽ tự động giải phóng.
	return 0;
}